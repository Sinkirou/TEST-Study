# 1. 定义一个动物类 Animal类, 方法: 吃
class Animal:
    def eat(self):
        print('饿了要吃东西....')


# 2. 定义一个狗类 Dog类,继承动物类
class Dog(Animal):
    # 2.2 在 Dog 类,定义叫的方法
    def bark(self):
        print('汪汪汪叫.....')


# 3. 定义一个哮天犬类, 继承狗类
class XTQ(Dog):
    pass


# 2.1 定义 Dog类的对象,查看是否可以调用 eat 方法
dog = Dog()
dog.eat()  # 子类对象调用父类中的方法

# 3.1 定义XTQ类对象, 调用方法
xtq = XTQ()
xtq.bark()  # 子类调用父类中方法
xtq.eat()  # 子类调用爷爷类的方法
