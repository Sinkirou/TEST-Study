class Dog:
    # 定义类属性
    count = 0

    def __init__(self):
        # 可以添加实例属性
        # 修改类属性的值
        Dog.count += 1


# 创建对象来验证代码书写是否正确
print(Dog.count)  # 0
dog = Dog  # 这不是创建
print(Dog.count)  # 0
dog1 = Dog()  # 创建对象
print(Dog.count)  # 1
dog2 = dog1   # 不是创建对象
Dog()   # 创建对象
print(Dog.count)  # 2


