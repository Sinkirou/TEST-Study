# for i in range(5):  # 循环 5 次,i 最大的数字是 4
for i in range(10):  # 循环 10 次,i 最大的数字是 9
    print('我错了', i)