my_list1 = ['good', 'good', 'study', 'day', 'day', 'up']

# 将列表中每个数据(单词)使用空格连接成一个字符串

str1 = ' '.join(my_list1)
print(str1)

# 将列表中每个数据(单词)使用 _*_ 连接成一个字符串
str2 = '_*_'.join(my_list1)
print(str2)

