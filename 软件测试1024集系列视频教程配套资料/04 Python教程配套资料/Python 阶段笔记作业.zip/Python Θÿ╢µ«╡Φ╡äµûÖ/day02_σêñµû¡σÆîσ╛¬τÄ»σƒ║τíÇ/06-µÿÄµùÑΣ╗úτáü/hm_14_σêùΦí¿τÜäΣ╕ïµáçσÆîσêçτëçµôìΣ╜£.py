# 定义列表
my_list = ['小明', 18, 170.8, 3.14, True]

# 需求: 想要获取打印 '小明', 即 取 下标为 0 的数据
print(my_list[0])

# 需求: 想要打印 18
print(my_list[1])

# 需求: 想要获取  小明 和 18
print(my_list[0:2])   # ['小明', 18]

# 获取 列表中数据的个数, 长度
num = len(my_list)
print(num)  # 5
