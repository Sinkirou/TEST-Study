# 定义字符串
name = 'xiao'

for i in name:
    print('我错了', i)

