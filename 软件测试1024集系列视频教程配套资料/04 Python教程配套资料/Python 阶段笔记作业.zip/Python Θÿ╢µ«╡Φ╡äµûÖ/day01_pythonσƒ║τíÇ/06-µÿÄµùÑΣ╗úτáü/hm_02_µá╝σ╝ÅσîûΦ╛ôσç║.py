name = '小王'
age = 18
height = 178.9

print(f"我的名字是{name},年龄是{age}岁,身高是{height}cm")
print("我的名字是{},年龄是{}岁,身高是{}cm".format(name, age, height))
