# 1. 导入随机数工具包
import random

# 2. 使用工具包中的工具产生随机数
num = random.randint(1, 3)
print(num)


