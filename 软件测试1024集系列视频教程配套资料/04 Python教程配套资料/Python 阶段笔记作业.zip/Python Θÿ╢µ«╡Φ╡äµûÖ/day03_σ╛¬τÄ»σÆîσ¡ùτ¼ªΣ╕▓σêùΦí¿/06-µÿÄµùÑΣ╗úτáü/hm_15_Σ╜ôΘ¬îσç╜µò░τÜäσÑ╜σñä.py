def func():
    print('我要好好学习')
    print('我要好好学习')
    print('我要好好学习')
    print('将来找一个好o工作')
    print('我要走上人生巅峰')


func()
print('------表示很多其他的代码 -------')
func()

print('------表示很多其他的代码 -------')
func()
