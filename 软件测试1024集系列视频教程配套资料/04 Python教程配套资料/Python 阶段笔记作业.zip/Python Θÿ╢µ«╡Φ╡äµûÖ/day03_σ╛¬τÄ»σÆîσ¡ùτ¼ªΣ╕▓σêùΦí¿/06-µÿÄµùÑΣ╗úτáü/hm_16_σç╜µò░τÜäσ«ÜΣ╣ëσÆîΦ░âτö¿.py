# 1. 编写一个打招呼 say_hello 的函数，封装三行打招呼的代码
# 2. 在函数下方调用打招呼的代码


# 函数的定义,不会执行函数中的代码
def say_hello():
    print('hello 1')
    print('hello 2')
    print('hello 3')


# 想要执行函数中的代码,需要调用
say_hello()

say_hello()
