my_list = ['a', 'b', 'c']

# 得到新列表
my_list1 = my_list[::-1]
print(my_list1)  # ['c', 'b', 'a']

# 直接修改原列表
my_list.reverse()
print(my_list)  # ['c', 'b', 'a']
