my_list = [1, 4, 7, 2, 5, 8, 3, 6, 9]

# 升序排序
my_list.sort()  # None
print(my_list)

# 降序排序
my_list.sort(reverse=True)  # None
print(my_list)
