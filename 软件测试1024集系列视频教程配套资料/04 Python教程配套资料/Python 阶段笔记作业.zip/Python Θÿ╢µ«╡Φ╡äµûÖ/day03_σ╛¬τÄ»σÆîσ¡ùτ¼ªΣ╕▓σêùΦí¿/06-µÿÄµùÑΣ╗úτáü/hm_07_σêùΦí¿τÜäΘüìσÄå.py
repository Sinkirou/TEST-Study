my_list = ['aa', 'vv', 'cc', 'dd']

for i in my_list:
    print(i)