def say_hello():
    """输出打印 hello """
    print('hello')


say_hello()