# 定义字典
# 1. 定义空字典
my_dict = {}

print(type(my_dict))  # <class 'dict'>

# 2. 定义非空字典 , 定义字典包含以下键值对 姓名, 年龄
my_dict1 = {"name": '小明', "age": 18}
print(my_dict1)

# len() 求长度, 在字典中,一个键值对,是一个数据
print(len(my_dict1))
