# 1. 打开文件
f = open('b.txt', 'w', encoding='utf-8')
# 2. 写入内容
# f.write('好好学习\nday day up')
f.write('1234')
# 3. 关闭文件
f.close()



