import json
import random

my_list = [1, 2, 3, {'name': "小王", 'age': 18}, {'name': "小名", 'age': 18},
           {'name': "小红", 'age': 18}, {'name': "小绿", 'age': 18}]

with open('data.json', 'w', encoding='utf-8') as f:
    # json.dump(my_list, f)  # 直接保存,汉字显示的不认识
    # json.dump(my_list, f, ensure_ascii=False)  #
    # json.dump(my_list, f, ensure_ascii=False, indent=1)  #
    # json.dump(my_list, f, ensure_ascii=False, indent=2)  #
    json.dump(my_list, f, ensure_ascii=False, indent=4)  #
    print('保存成功')
