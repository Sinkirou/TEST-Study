# 方式一
# import random
# num = random.randint(1, 10)
# print(num)

# 方式二
# from random import randint
# from random import randint
#
# num = randint(1, 10)
# print(num)

# 方式三
from random import *

num = randint(1, 10)
print(num)

