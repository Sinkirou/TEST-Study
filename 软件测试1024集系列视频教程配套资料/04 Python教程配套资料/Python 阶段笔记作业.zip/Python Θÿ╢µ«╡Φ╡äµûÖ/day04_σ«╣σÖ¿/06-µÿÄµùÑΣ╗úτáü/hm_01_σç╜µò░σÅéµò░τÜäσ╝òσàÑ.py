"""
代码的目的: 说明为什么需要参数,以及参数的好处
"""


def login_test():
    print("1. 打开浏览器")
    print('2. 输入网址')
    print('3. 输入用户名:', '1388888888')
    print('4. 输入密码', '123456')
    print('5. 输入验证码')
    print('6. 点击登录')


def login_test_1():
    print("1. 打开浏览器")
    print('2. 输入网址')
    print('3. 输入用户名:', '1377777777')
    print('4. 输入密码', '123456')
    print('5. 输入验证码')
    print('6. 点击登录')

login_test()