# 定义一个函数 add, 可以对两个数字进行求和运算.
def add(a, b):
    c = a + b
    print(c)


add(1, 2)
add(10, 20)
add(100, 200)
